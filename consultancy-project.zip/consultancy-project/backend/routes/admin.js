import express from "express";
import Consultant from "../models/Consultant.js";
const router = express.Router();

router.get("/consultants/pending", async (req, res) => {
  try {
    const consultants = await Consultant.find({ approved: false });
    res.json(consultants);
  } catch (err) {
    res.status(500).json({ message: "Error fetching data" });
  }
});

router.patch("/consultants/approve/:id", async (req, res) => {
  try {
    await Consultant.findByIdAndUpdate(req.params.id, { approved: true });
    res.json({ message: "Consultant approved" });
  } catch (err) {
    res.status(500).json({ message: "Approval failed" });
  }
});

router.delete("/consultants/delete/:id", async (req, res) => {
  try {
    await Consultant.findByIdAndDelete(req.params.id);
    res.json({ message: "Consultant deleted" });
  } catch (err) {
    res.status(500).json({ message: "Deletion failed" });
  }
});

export default router;
