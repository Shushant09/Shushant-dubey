import mongoose from "mongoose";

const consultantSchema = new mongoose.Schema({
  name: String,
  field: String,
  bio: String,
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  approved: {
    type: Boolean,
    default: false
  }
});

export default mongoose.model("Consultant", consultantSchema);
